# Autograding Example: C
This example project is written in C, and tested with make and bash scripts.

### The assignment
The tests are currently failing because we're printing the wrong string. Correcting the `printf` will fix the tests.

### Setup command
N/A

### Run command
`make test`

### Notes
- `gcc` can be used to compile and link C applications for use with existing test harnesses or C testing frameworks.
